# Changelog

## 1.0.7 - 2026-11-23

### Added

- Add custom autoscaling behavior and custom command args interceptor

## 1.0.6 - 2026-03-16

### Added

- Add httproute feature 

## 1.0.5 - 2025-02-27

### Added

- Add vault secret operator secret injector

## 1.0.4 - 2024-08-01

### Added

- Add custom strategy percentage

## 1.0.3 - 2024-07-02

### Added

- Add env injector feature to Deployment 

## 1.0.2 - 2024-07-02

### Removed

- Remove ingress annotations on default values.yaml, so we have to manually add the ingress annotation.

## 1.0.1 - 2024-05-28

### Fixed

- Fix bug on custom image

## 1.0.0 - 2024-05-20

### Added

- Atlas started, this version has a bug on custom image

